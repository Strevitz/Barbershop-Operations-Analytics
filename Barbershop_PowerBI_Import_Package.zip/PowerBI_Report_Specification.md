# Power BI model / report build specification

DATASET
- Primary fact: Transactions
- Capacity fact: Capacity
- Date dimension: create with CALENDAR(MIN(Transactions[Date]), MAX(Transactions[Date]))
- Relate Date[Date] -> Transactions[Date]
- Relate Date[Date] -> Capacity[Date]
- Currency: USD
- Data period: September 2025 - August 2026
- All portfolio financial figures are synthetic/anonymized.

REPORT PAGE 1 — EXECUTIVE DASHBOARD
KPI cards:
1. Total Revenue
2. Total Clients
3. Average Ticket
4. Avg Clients / Open Day
Charts:
- Monthly Revenue trend (line)
- Revenue by Barber (clustered bar)
- Clients by Service (bar)
- Revenue by Service (bar)
- Capacity Utilization by Barber (bar)
Slicers:
- Date
- Barber
- Service
- Day of Week

REPORT PAGE 2 — BARBER PERFORMANCE
- Revenue by Barber
- Clients by Barber
- Average Ticket by Barber
- Capacity Utilization by Barber
- Monthly revenue trend with Barber legend

REPORT PAGE 3 — SERVICE & DEMAND
- Revenue by Service
- Client count by Service
- Average ticket by Service
- Demand by weekday
- Demand by hour
- Heatmap: weekday x hour

REPORT PAGE 4 — CAPACITY
- Scheduled hours
- Capacity
- Actual clients
- Utilization
- Daily capacity trend
- Barber-level capacity table

Suggested model name: Barbershop Operations Analytics
Suggested report title: BARBERSHOP OPERATIONS | POWER BI ANALYTICS
